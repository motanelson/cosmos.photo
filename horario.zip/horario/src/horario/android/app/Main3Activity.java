package horario.android.app;


import android.app.*;
import android.os.*;



import android.app.*;
import android.os.*;


import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.view.KeyEvent.Callback;
import 	android.view.InputEvent;
import	android.view.KeyEvent;
import android.view.MenuInflater;
import 	android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.ViewConfiguration;

import android.content.ContextWrapper;
import android.view.ContextThemeWrapper;

import android.content.Context;


import android.app.Activity;
import android.os.Bundle;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import android.os.Environment;
import android.util.Log;
import android.widget.TextView;
import java.io.File;
import java.io.FileWriter;
import java.io.BufferedWriter;

import android.app.ListActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;



import android.app.ListActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;

import java.lang.Object;

import android.app.ListActivity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;
import android.text.TextUtils;

import android.view.View; 
import android.view.View.OnClickListener; 
import android.widget.Button; 
import android.widget.EditText; 
import android.widget.TextView;
import java.lang.Object;
import java.lang.Throwable;
import java.lang.Exception;
import java.lang.Exception;
import java.io.IOException;
import android.webkit.WebView;
import android.view.KeyEvent.Callback;
import java.lang.Object;
import android.content.Context;
import android.content.ContextWrapper;
import android.view.ContextThemeWrapper;
import android.app.Activity;
import android.view.MenuItem;
import android.widget.Toast; 
import android.view.InputEvent;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import java.util.List;
import android.app.ListActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;
import java.util.AbstractCollection;
import java.util.AbstractList;
import java.util.ArrayList;
import 	android.content.Context;
import android.content.ContextWrapper;
import android.view.ContextThemeWrapper;
import android.app.Activity;
import android.app.ListActivity;
import java.io.*;
import 
java.io.InputStream;
import java.io.FileInputStream;

import 	java.util.Collections;
import java.util.List;
import java.util.Comparator;
import java.util.Arrays;
import android.util.Base64;


import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import java.io.RandomAccessFile;
import 	java.io.RandomAccessFile;

import 	java.nio.charset.Charset;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import android.app.ListActivity;
import android.os.Bundle;
import android.widget.SimpleAdapter;




import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;


import android.app.Activity;
import android.content.Context;
import android.graphics.*;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.*;

import android.graphics.Paint.Style;
import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.os.Bundle;
import android.widget.ImageView;


import java.lang.Object;
import java.util.Random;

import java.lang.Object;
import android.view.View;

import 
android.view.ViewGroup.LayoutParams;
import	android.view.ViewGroup.MarginLayoutParams;



import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.database.sqlite.SQLiteOpenHelper;


import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.view.KeyEvent.Callback;
import 	android.view.InputEvent;
import	android.view.KeyEvent;
import android.view.MenuInflater;
import 	android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.ViewConfiguration;

import android.content.ContextWrapper;
import android.view.ContextThemeWrapper;

import android.content.Context;


import android.app.Activity;
import android.os.Bundle;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import android.os.Environment;
import android.util.Log;
import android.widget.TextView;
import java.io.File;
import java.io.FileWriter;
import java.io.BufferedWriter;

import android.app.ListActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;



import android.app.ListActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;

import java.lang.Object;

import android.app.ListActivity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;
import android.text.TextUtils;

import android.view.View; 
import android.view.View.OnClickListener; 
import android.widget.Button; 
import android.widget.EditText; 
import android.widget.TextView;
import java.lang.Object;
import java.lang.Throwable;
import java.lang.Exception;
import java.lang.Exception;
import java.io.IOException;
import android.webkit.WebView;
import android.view.KeyEvent.Callback;
import java.lang.Object;
import android.content.Context;
import android.content.ContextWrapper;
import android.view.ContextThemeWrapper;
import android.app.Activity;
import android.view.MenuItem;
import android.widget.Toast; 
import android.view.InputEvent;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import java.util.List;
import android.app.ListActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;
import java.util.AbstractCollection;
import java.util.AbstractList;
import java.util.ArrayList;
import 	android.content.Context;
import android.content.ContextWrapper;
import android.view.ContextThemeWrapper;
import android.app.Activity;
import android.app.ListActivity;
import java.io.*;
import 
java.io.InputStream;
import java.io.FileInputStream;

import 	java.util.Collections;
import java.util.List;
import java.util.Comparator;
import java.util.Arrays;
import android.util.Base64;


import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import java.io.RandomAccessFile;
import 	java.io.RandomAccessFile;

import 	java.nio.charset.Charset;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import android.app.ListActivity;
import android.os.Bundle;
import android.widget.SimpleAdapter;




import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;


import android.app.Activity;
import android.content.Context;
import android.graphics.*;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.*;

import android.graphics.Paint.Style;
import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.os.Bundle;
import android.widget.ImageView;


import java.lang.Object;
import java.util.Random;

import java.lang.Object;
import android.view.View;

import 
android.view.ViewGroup.LayoutParams;
import	android.view.ViewGroup.MarginLayoutParams;

import android.app.Application;

import android.content.Context;



public class Main3Activity extends Activity 
{
	private Context context;
	private ListView listview;
	private SQLiteDatabase db;
	private Cursor cursor;
private int entidade=-1;





























	private ArrayList<Integer> tecla = new ArrayList<Integer>();

	private ArrayList<String> string1 = new ArrayList<String>();
	private ArrayList<String> string3 = new ArrayList<String>();
	private ArrayList<String> string2 = new ArrayList<String>();
	private ArrayList<String> string4 = new ArrayList<String>();
private ArrayList<String> string5 = new ArrayList<String>();
	private ArrayList<String> string6= new ArrayList<String>();
	private ArrayList<String> string7 = new ArrayList<String>();
	private ArrayList<String> string8 = new ArrayList<String>();


private ArrayList<String> string9 = new ArrayList<String>();
	private ArrayList<String> string10= new ArrayList<String>();
	private ArrayList<String> string11 = new ArrayList<String>();
	private ArrayList<String> string12 = new ArrayList<String>();
private ArrayList<String> string13 = new ArrayList<String>();
	private ArrayList<String> string14= new ArrayList<String>();
	private ArrayList<String> string15= new ArrayList<String>();
	private ArrayList<String> string16= new ArrayList<String>();
private ArrayList<String> string17= new ArrayList<String>();
private ArrayList<String> string18 = new ArrayList<String>();
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.main2);
String obras="";
		context=this;
		Double total=0.0d;
		Double valor=0.0d;
		setTitle("horario");
		int st=0,en=0;
		
		File f2=new File("/sdcard/app.android/horario.android.app/horario.data");

		
		int ii;
		boolean b;
		try{
			

			db =   openOrCreateDatabase  (f2.toString(),  Context.MODE_PRIVATE,   null);
			
			cursor = db.query("comunicacao", new String[] { "Id" , "a" ,  "b" , "c" , "d" , "e","f"},null,null,null,null,null ,null);

			if (cursor.moveToFirst()) {

				obras=cursor.getString(4).trim();

setTitle(obras);


				if(obras.trim() =="-1") setTitle("não a entidade selecionada");
			
				}
			if(obras.trim() =="-1") {
				cursor = db.query("movimento", new String[] { "Id" , "semana" ,  "data" ,"ferias" , "obra" , "inicio" , "fim" , "horas", "inicio2" , "fim2" , "horas2", "almoco","jantar","cupao","ajuda",  "ilha" , "matricula", "observacoes", "prevencao"},null,null,null,null,null,null);
				}else{
             cursor = db.query("movimento", new String[] { "Id" , "semana" ,  "data" ,"ferias" , "obra" , "inicio" , "fim" , "horas", "inicio2" , "fim2" , "horas2", "almoco","jantar","cupao","ajuda",  "ilha" , "matricula", "observacoes", "prevencao"},null,null,null,null,"obra='"+obras+"'",null);
			}
			total=0.00;

			if (cursor.moveToFirst()) {
				do{
					tecla.add(cursor.getInt(0));
					string1.add(cursor.getString(1));
					string2.add(cursor.getString(2));
					string3.add(cursor.getString(3));
					
					string4.add(cursor.getString(4));
					string5.add(cursor.getString(5));
					string6.add(cursor.getString(6));
					string7.add(cursor.getString(7));
					
					string8.add(cursor.getString(8));
					string9.add(cursor.getString(9));
					string10.add(cursor.getString(10));
					string11.add(cursor.getString(11));
					
					string12.add(cursor.getString(12));
					string13.add(cursor.getString(13));
					string14.add(cursor.getString(14));
					string15.add(cursor.getString(15));
					
					string16.add(cursor.getString(16));
					string17.add(cursor.getString(17));
					string18.add(cursor.getString(18));
					
 total++;
				}while(cursor.moveToNext());
			}

setTitle(total.toString());
		}catch(Exception e){

			setTitle(e.toString());
		}
		tecla.add(-1);
		string1.add("adicionar novo movimento");
		string2.add("");
		string3.add("");
		string4.add("");
		string5.add("");
		string6.add("");
		string7.add("");
         string8.add("");
		string9.add("");
		string10.add("");
		string11.add("");
		string12.add("");
		string13.add("");
		string14.add("");
		string15.add("");
		string16.add("");
		string17.add("");
		string18.add("");
	
		

        listview = (ListView) findViewById(R.id.listview2);

    listview.setAdapter(new yourAdaptar2(this, string1,string2,string3,string4,string5,string6,string7,string8,string9,string10,string11,string12,string13,string14,string15,string16,string17,string18));
		listview.setOnItemClickListener(new OnItemClickListener() {
				public void onItemClick(AdapterView<?> parent, View view,int position, long id) {
					// When clicked, show a toast with the TextView text


					String ss=Integer.toString( tecla.get(position));
					String sss=string1.get(position);

					if(tecla.get(position)==-1){
						sss="";
					}
					
					File f2=new File("/sdcard/app.android/horario.android.app/horario.data");
					
					
					db =   openOrCreateDatabase  (f2.toString(),  Context.MODE_PRIVATE,   null);
					db.delete("comunicacao2","Id<0",null);
					db.delete("comunicacao2","Id>0",null);
					db.delete("comunicacao2","Id=0",null);
					String s="INSERT INTO comunicacao2 (a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t) VALUES ('"+ss+"','"+sss+"','"+string2.get(position)+"','"+string3.get(position)+"','"+string4.get(position)+"','"+string5.get(position)+"','"+string6.get(position)+"','"+string7.get(position)+"','"+string8.get(position)+"','"+string9.get(position)+"','"+string10.get(position)+"','"+string11.get(position)+"','"+string12.get(position)+"','"+string13.get(position)+"','"+string14.get(position)+"','"+string15.get(position)+"','"+string16.get(position)+"','"+string17.get(position)+"','"+string18.get(position)+"','"+""+"'"+")";
					setTitle(s);
					db.execSQL(s);

					db.close();





					try{
						Intent intent = new Intent(context,Main4Activity.class);

						startActivity(intent);  

						finish(); 
					}catch(Exception e){}

				}
			});



    }
}



